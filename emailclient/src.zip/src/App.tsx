import React, { useState, useEffect } from 'react';
import Header from './Header';
import EmailList from './EmailList';
import EmailViewer from './EmailViewer';
import Email from './email';
import './App.css';

const App: React.FC = () => {
    const [tags, setTags] = useState<string[]>([]);
    const [emails, setEmails] = useState<Email[]>([]);
    const [selectedTag, setSelectedTag] = useState<string>('');
    const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);

    useEffect(() => {
        fetchTags();
    }, []);

    const fetchTags = async () => {
        const response = await fetch('http://localhost:3001/tags');
        const data = await response.json();
        setTags(data);
        if (data.length > 0) {
            setSelectedTag(data[0]);
            fetchEmails(data[0]);
        }
    };

    const fetchEmails = async (tag = '') => {
        const response = await fetch(`http://localhost:3001/emails?tags=${tag}`);
        const data = await response.json();
        setEmails(data);
    };

    const handleTagClick = (tag: string) => {
        setSelectedTag(tag);
        fetchEmails(tag);
    };

    const handleEmailClick = (email: Email) => {
        setSelectedEmail(email);
    };

    return (
        <div className="container">
            <Header tags={tags} selectedTag={selectedTag} onTagClick={handleTagClick} />
            <div className="content">
                <EmailList emails={emails} onEmailClick={handleEmailClick} />
                <EmailViewer email={selectedEmail} />
            </div>
        </div>
    );
};

export default App;

