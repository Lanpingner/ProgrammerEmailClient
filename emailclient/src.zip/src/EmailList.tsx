import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArchive, faReply, faChevronDown, faChevronUp, faThumbtack, faEye } from '@fortawesome/free-solid-svg-icons';
import Email from './email';
import './EmailList.css';

interface EmailListProps {
    emails: Email[];
    onEmailClick: (email: Email) => void;
}

const EmailList: React.FC<EmailListProps> = ({ emails, onEmailClick }) => {
    const [expandedEmailId, setExpandedEmailId] = useState<number | null>(null);

    const handleExpandClick = (emailId: number) => {
        setExpandedEmailId(expandedEmailId === emailId ? null : emailId);
    };

    return (
        <aside className="sidebar">
            <div className="search-bar">
                <input type="text" placeholder="Search" />
            </div>
            <div className="email-list">
                {emails.map(email => (
                    <div key={email.id} className="email-item">
                        <div className="email-summary">
                            <input type="checkbox" className="email-checkbox" />
                            <FontAwesomeIcon icon={faThumbtack} className="icon pin" />
                            <FontAwesomeIcon icon={faEye} className="icon view" />
                            <button className="icon-expand" onClick={() => handleExpandClick(email.id)}>
                                <FontAwesomeIcon icon={expandedEmailId === email.id ? faChevronUp : faChevronDown} />
                            </button>
                            <span className="email-subject" onClick={() => onEmailClick(email)}>
                                {email.subject}
                            </span>
                            <span className="email-date">{new Date(email.date).toLocaleDateString()}</span>
                            <a href="#" className="icon reply">
                                <FontAwesomeIcon icon={faReply} />
                            </a>
                            <a href="#" className="icon archive">
                                <FontAwesomeIcon icon={faArchive} />
                            </a>
                        </div>
                        {expandedEmailId === email.id && (
                            <div className="email-details">
                                <p><strong>From:</strong> {email.from.name} &lt;{email.from.address}&gt;</p>
                                {email.to && <p><strong>To:</strong> {email.to.accounts[0].address}</p>}
                                {email.cc && <p><strong>CC:</strong> {email.cc.accounts?.map(acc => `${acc.name} <${acc.address}>`).join(', ')}</p>}
                                {email.bcc && <p><strong>BCC:</strong> {email.bcc.accounts?.map(acc => `${acc.name} <${acc.address}>`).join(', ')}</p>}
                                <p><strong>Date:</strong> {new Date(email.date).toLocaleString()}</p>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </aside>
    );
};

export default EmailList;

