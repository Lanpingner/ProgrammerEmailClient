interface Email {
    id: number;
    subject: string;
    content: string;
    to: { accounts: { name: string; address: string }[] } | null;
    from: { name: string; address: string };
    cc: { accounts: { name: string; address: string }[] } | null;
    bcc: { accounts: { name: string; address: string }[] } | null;
    date: string;
}

export default Email;
